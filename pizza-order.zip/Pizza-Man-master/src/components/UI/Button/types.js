export const DANGER = "DANGER"
export const NORMAL = "NORMAL"
export const SECONDARY = "SECONDARY"